# Hostel Token App — v7 Firebase Backend Foundation

This version keeps the existing UI/data-flow work and adds a Firebase backend layer for the next stage.

## Firebase setup
1. Install FlutterFire CLI.
2. Create a Firebase project.
3. Enable **Authentication → Email/Password**.
4. Create a **Cloud Firestore** database.
5. From this project folder run:
   `flutterfire configure`
6. This generates `lib/firebase_options.dart`.
7. Initialize Firebase in `main()` before using `HostelBackendService`:

```dart
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform,
);
```

## Firestore collections
- `students`
- `tokens`
- `menus`

The service in `lib/backend_service.dart` contains register/login, student profile, token creation/history, and menu read/write operations.

## Important
Firebase credentials/config are intentionally not included in this ZIP. They must belong to your own Firebase project.

## Android package name (v8 setup)
The Android package/application ID is:
`com.nptc.mcet.hosteltokenapp`

Use this exact value when adding the Android app in Firebase Console.
Do not use commas or spaces in the package name.

## Next Firebase step
After creating your Firebase project, add an Android app with the package name above and download `google-services.json` into `android/app/`. Then run FlutterFire configuration from the project root to generate `lib/firebase_options.dart`.
