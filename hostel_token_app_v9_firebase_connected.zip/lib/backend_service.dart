import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firebase backend layer for the Hostel Token App.
///
/// The UI can keep using the current AppData while Firebase is configured.
/// Run `flutterfire configure` to generate firebase_options.dart, then call
/// Firebase.initializeApp(...) from main() before using this service.
class HostelBackendService {
  HostelBackendService._();
  static final instance = HostelBackendService._();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;

  Future<UserCredential> registerStudent({
    required String email,
    required String password,
    required String name,
    required String registerNumber,
    required String phone,
    required String category,
  }) async {
    final credential = await auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );

    await db.collection('students').doc(credential.user!.uid).set({
      'uid': credential.user!.uid,
      'name': name.trim(),
      'registerNumber': registerNumber.trim(),
      'phone': phone.trim(),
      'email': email.trim(),
      'category': category,
      'createdAt': FieldValue.serverTimestamp(),
      'active': true,
    });

    return credential;
  }

  Future<UserCredential> loginStudent({
    required String email,
    required String password,
  }) => auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

  Stream<DocumentSnapshot<Map<String, dynamic>>> studentProfile() {
    final uid = auth.currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return db.collection('students').doc(uid).snapshots();
  }

  Future<DocumentReference<Map<String, dynamic>>> createToken({
    required String type,
    required String date,
    required String menu,
    required int quantity,
  }) async {
    final uid = auth.currentUser?.uid;
    if (uid == null) throw StateError('Student is not logged in');

    return db.collection('tokens').add({
      'studentUid': uid,
      'type': type,
      'date': date,
      'menu': menu,
      'quantity': quantity,
      'status': 'Active',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myTokens() {
    final uid = auth.currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return db.collection('tokens')
        .where('studentUid', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> menus() =>
      db.collection('menus').orderBy('date').snapshots();

  Future<void> addMenu({
    required String date,
    required String snack,
    required String egg,
  }) => db.collection('menus').add({
        'date': date,
        'snack': snack,
        'egg': egg,
        'createdAt': FieldValue.serverTimestamp(),
      });
}
