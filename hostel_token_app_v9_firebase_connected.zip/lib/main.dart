
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';


class MenuDay {
  final String date;
  final String snack;
  final String egg;
  const MenuDay({required this.date, required this.snack, required this.egg});
}

class TokenRecord {
  final String id;
  final String type;
  final String date;
  final String status;
  final int quantity;
  const TokenRecord({required this.id, required this.type, required this.date, required this.status, required this.quantity});
}

class StudentRecord {
  final String name;
  final String reg;
  final String category;
  const StudentRecord({required this.name, required this.reg, required this.category});
}

class AppData extends ChangeNotifier {
  AppData._();
  static final instance = AppData._();

  final List<MenuDay> menus = [
    const MenuDay(date: '25 Sep 2026', snack: 'Sample Snack', egg: 'Boiled Egg'),
    const MenuDay(date: '26 Sep 2026', snack: 'Sample Snack 2', egg: 'Omelette'),
    const MenuDay(date: '27 Sep 2026', snack: 'Sample Snack 3', egg: 'Fried Egg'),
  ];

  final List<TokenRecord> tokens = [];
  final List<StudentRecord> students = const [
    StudentRecord(name: 'Student 001', reg: 'REG001', category: 'Management Quota'),
    StudentRecord(name: 'Student 002', reg: 'REG002', category: 'Government – General Rank'),
    StudentRecord(name: 'Student 003', reg: 'REG003', category: 'Government – 7.5% Category'),
  ];

  MenuDay get todayMenu => menus.first;

  void addMenu(MenuDay menu) {
    menus.add(menu);
    notifyListeners();
  }

  TokenRecord addToken(String type) {
    final prefix = type == 'Snack' ? 'SNK' : 'EGG';
    final id = '$prefix-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
    final token = TokenRecord(id: id, type: type, date: '25 Sep 2026', status: 'Active', quantity: 1);
    tokens.insert(0, token);
    notifyListeners();
    return token;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const HostelTokenApp());
}

class HostelTokenApp extends StatelessWidget {
  const HostelTokenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hostel Token',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF123B69)),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final registerController = TextEditingController();
  final passwordController = TextEditingController();
  bool obscure = true;

  @override
  void dispose() {
    registerController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void login() {
    if (registerController.text.trim().isEmpty ||
        passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter Register Number and Password')),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                width: 86,
                height: 86,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF1FA),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(
                  Icons.bed_outlined,
                  size: 52,
                  color: Color(0xFF123B69),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Hostel Token',
                style: TextStyle(
                  fontSize: 31,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF123B69),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Student Login',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF183A60),
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                'Login to access your tokens and more',
                style: TextStyle(color: Colors.blueGrey),
              ),
              const SizedBox(height: 28),

              _field(
                controller: registerController,
                hint: 'Register Number',
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _field(
                controller: passwordController,
                hint: 'Password',
                icon: Icons.lock_outline,
                obscureText: obscure,
                suffix: IconButton(
                  onPressed: () => setState(() => obscure = !obscure),
                  icon: Icon(
                    obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                    color: Colors.blueGrey,
                  ),
                ),
              ),
              const SizedBox(height: 22),

              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF123B69),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                  child: const Text(
                    'Login',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),

              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't have an account? "),
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const RegisterPage()),
                    ),
                    child: const Text(
                      'Register',
                      style: TextStyle(
                        color: Color(0xFF1670D2),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),
              Row(
                children: const [
                  Expanded(child: Divider()),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 14),
                    child: Text('OR', style: TextStyle(color: Colors.blueGrey)),
                  ),
                  Expanded(child: Divider()),
                ],
              ),
              const SizedBox(height: 18),

              TextButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.phone_android_outlined),
                label: const Text('Login with OTP'),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AdminLoginPage()),
                ),
                icon: const Icon(Icons.admin_panel_settings_outlined),
                label: const Text('Admin / Warden Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscureText = false,
    Widget? suffix,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: Colors.blueGrey),
        suffixIcon: suffix,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(vertical: 17),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFFDCE3EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFFDCE3EB)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFF123B69), width: 1.5),
        ),
      ),
    );
  }
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final register = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirm = TextEditingController();
  bool hidePassword = true;
  bool hideConfirm = true;

  @override
  void dispose() {
    register.dispose();
    phone.dispose();
    email.dispose();
    password.dispose();
    confirm.dispose();
    super.dispose();
  }

  void createAccount() {
    if ([register, phone, email, password, confirm]
        .any((c) => c.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }
    if (password.text != confirm.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Passwords do not match')),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const StudentTypePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 18, 24, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back),
              ),
              const SizedBox(height: 8),
              const Text(
                'Register',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF123B69),
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Create your account',
                style: TextStyle(color: Colors.blueGrey, fontSize: 16),
              ),
              const SizedBox(height: 25),
              _input(register, 'Register Number', Icons.person_outline),
              const SizedBox(height: 13),
              _input(phone, 'Phone Number', Icons.phone_outlined,
                  keyboard: TextInputType.phone),
              const SizedBox(height: 13),
              _input(email, 'Email ID', Icons.mail_outline,
                  keyboard: TextInputType.emailAddress),
              const SizedBox(height: 13),
              _input(password, 'Create Password', Icons.lock_outline,
                  obscure: hidePassword,
                  suffix: IconButton(
                    onPressed: () =>
                        setState(() => hidePassword = !hidePassword),
                    icon: Icon(hidePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                  )),
              const SizedBox(height: 13),
              _input(confirm, 'Confirm Password', Icons.lock_outline,
                  obscure: hideConfirm,
                  suffix: IconButton(
                    onPressed: () =>
                        setState(() => hideConfirm = !hideConfirm),
                    icon: Icon(hideConfirm
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                  )),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: createAccount,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF123B69),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                  child: const Text(
                    'Register',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: const Text.rich(
                    TextSpan(
                      text: 'Already have an account? ',
                      children: [
                        TextSpan(
                          text: 'Login',
                          style: TextStyle(
                            color: Color(0xFF1670D2),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _input(
    TextEditingController controller,
    String hint,
    IconData icon, {
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboard,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboard,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: Colors.blueGrey),
        suffixIcon: suffix,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFFDCE3EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFFDCE3EB)),
        ),
      ),
    );
  }
}

class StudentTypePage extends StatefulWidget {
  const StudentTypePage({super.key});

  @override
  State<StudentTypePage> createState() => _StudentTypePageState();
}

class _StudentTypePageState extends State<StudentTypePage> {
  int selected = -1;

  final options = const [
    'Management Quota',
    'Government Quota – General Rank',
    'Government Quota – 7.5%',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Type')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Select your student category',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('This decides which token plans are available to you.',
                style: TextStyle(color: Colors.blueGrey)),
            const SizedBox(height: 24),
            ...List.generate(options.length, (i) {
              return Card(
                child: RadioListTile<int>(
                  value: i,
                  groupValue: selected,
                  onChanged: (v) => setState(() => selected = v!),
                  title: Text(options[i]),
                ),
              );
            }),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: selected == -1
                    ? null
                    : () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const HomePage()),
                        ),
                child: const Text('Continue'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    HomeContent(),
    TokenHistoryPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Hello, Rishva 👋', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF123B69))),
              SizedBox(height: 4),
              Text('CSE • 2nd Year\nHostel Student', style: TextStyle(color: Colors.blueGrey, height: 1.35)),
            ])),
            CircleAvatar(radius: 27, backgroundColor: Color(0xFFE6EDF5), child: Icon(Icons.person, color: Color(0xFF8B98A8), size: 32)),
          ]),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: _TokenCard(icon: Icons.cookie_outlined, title: "Today's\nSnack Token", value: 'FREE', subtitle: 'Qty : 1', status: 'Available', tint: const Color(0xFFFFF1E4), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SnackTokenPage())))),
            const SizedBox(width: 12),
            Expanded(child: _TokenCard(icon: Icons.egg_outlined, title: "Today's\nEgg Token", value: 'FREE / ₹250', subtitle: 'Based on category', status: 'View', tint: const Color(0xFFF0EAFF), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EggTokenPage())))),
          ]),
          const SizedBox(height: 14),
          Card(color: const Color(0xFFE9F8F1), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)), child: const ListTile(leading: CircleAvatar(backgroundColor: Color(0xFFD4F2E2), child: Icon(Icons.card_membership_outlined, color: Color(0xFF15935A))), title: Text('7.5% Student Plan', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('₹250 / 30 Days'), trailing: Chip(label: Text('View')))),
          const SizedBox(height: 22),
          const Text('Quick Access', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _QuickCard(icon: Icons.history, title: 'Token History', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TokenHistoryPage())))),
            const SizedBox(width: 12),
            Expanded(child: _QuickCard(icon: Icons.menu_book_outlined, title: 'View Menu', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MonthlyMenuPage())))),
          ]),
          const SizedBox(height: 22),
          const Text("Today's Menu", style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Card(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: const Padding(padding: EdgeInsets.all(17), child: Row(children: [Icon(Icons.restaurant_menu_outlined, color: Color(0xFF123B69), size: 30), SizedBox(width: 14), Expanded(child: Text('Snack and egg menu will be shown here', style: TextStyle(fontWeight: FontWeight.w700))), Icon(Icons.chevron_right, color: Colors.blueGrey)]))),
        ]),
      ),
    );
  }
}

class _TokenCard extends StatelessWidget {
  final IconData icon; final String title; final String value; final String subtitle; final String status; final Color tint; final VoidCallback onTap;
  const _TokenCard({required this.icon, required this.title, required this.value, required this.subtitle, required this.status, required this.tint, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Ink(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(backgroundColor: Colors.white, child: Icon(icon, color: const Color(0xFF123B69))), const SizedBox(height: 11), Text(title, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.25)), const SizedBox(height: 7), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF123B69))), const SizedBox(height: 2), Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)), const SizedBox(height: 9), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Text(status, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)))])));
}

class _QuickCard extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const _QuickCard({required this.icon, required this.title, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(15), child: Ink(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE1E7EE))), child: Row(children: [Icon(icon, color: const Color(0xFF123B69)), const SizedBox(width: 9), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))), const Icon(Icons.chevron_right, size: 19, color: Colors.blueGrey)])));
}

class SnackTokenPage extends StatelessWidget {
  const SnackTokenPage({super.key});
  @override
  Widget build(BuildContext context) => _TokenDetailScaffold(title: 'Snack Token', icon: Icons.cookie_outlined, iconBg: const Color(0xFFFFE6D2), heading: 'Snack Token', subtitle: 'Free for All Students', details: [('Today', AppData.instance.todayMenu.snack), ('Quantity', '1 per day'), ('Validity', 'Daily as per menu schedule'), ('Applicable For', 'All Students')], button: 'Get Snack Token', onPressed: () { final token = AppData.instance.addToken('Snack'); _showToken(context, token.id); });
}

class EggTokenPage extends StatelessWidget {
  const EggTokenPage({super.key});
  @override
  Widget build(BuildContext context) => _TokenDetailScaffold(title: 'Egg Token', icon: Icons.egg_outlined, iconBg: const Color(0xFFEDE4FF), heading: 'Egg Token', subtitle: 'Available for all students', details: [('Today', AppData.instance.todayMenu.egg), ('Price', 'FREE for Management & General Rank'), ('7.5% Category', '₹250 / 30 Days'), ('Validity', 'As per menu schedule')], button: 'Get Egg Token', onPressed: () { final token = AppData.instance.addToken('Egg'); _showToken(context, token.id); });
}

class _TokenDetailScaffold extends StatelessWidget {
  final String title, heading, subtitle, button; final IconData icon; final Color iconBg; final List<(String,String)> details; final VoidCallback onPressed;
  const _TokenDetailScaffold({required this.title, required this.icon, required this.iconBg, required this.heading, required this.subtitle, required this.details, required this.button, required this.onPressed});
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: const Color(0xFFF7F9FC), appBar: AppBar(title: Text(title), backgroundColor: Colors.transparent), body: SingleChildScrollView(padding: const EdgeInsets.all(22), child: Column(children: [const SizedBox(height: 14), CircleAvatar(radius: 54, backgroundColor: iconBg, child: Icon(icon, size: 58, color: const Color(0xFF123B69))), const SizedBox(height: 18), Text(heading, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Color(0xFF123B69))), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: Colors.blueGrey)), const SizedBox(height: 28), Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(children: details.map((d) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Row(children: [Expanded(child: Text(d.$1, style: const TextStyle(color: Colors.blueGrey))), Expanded(child: Text(d.$2, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w700)))]))).toList())), const SizedBox(height: 28), SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: onPressed, child: Text(button, style: const TextStyle(fontWeight: FontWeight.w800)))), const SizedBox(height: 15), const Text('Please collect your token from the hostel canteen counter.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey))])));
}

void _showToken(BuildContext context, String tokenId) {
  showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(padding: const EdgeInsets.fromLTRB(24, 8, 24, 30), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.qr_code_2, size: 130, color: Color(0xFF123B69)), const SizedBox(height: 10), const Text('Token Generated', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(tokenId, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8), const Text('Show this token at the hostel canteen.', style: TextStyle(color: Colors.blueGrey))]));
}

class TokenHistoryPage extends StatelessWidget {
  const TokenHistoryPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: AppData.instance,
    builder: (_, __) => Scaffold(
      appBar: AppBar(title: const Text('Token History')),
      body: AppData.instance.tokens.isEmpty
        ? const Center(child: Text('No tokens generated yet', style: TextStyle(color: Colors.blueGrey)))
        : ListView.builder(padding: const EdgeInsets.all(16), itemCount: AppData.instance.tokens.length, itemBuilder: (_, i) {
            final t = AppData.instance.tokens[i];
            return Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(
              leading: CircleAvatar(backgroundColor: t.type == 'Egg' ? const Color(0xFFEDE4FF) : const Color(0xFFFFE6D2), child: Icon(t.type == 'Egg' ? Icons.egg_outlined : Icons.cookie_outlined, color: const Color(0xFF123B69))),
              title: Text('${t.type} Token', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${t.id} • ${t.date} • Qty ${t.quantity}'),
              trailing: Text(t.status, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w700)),
            ));
          }),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Profile')), body: ListView(padding: const EdgeInsets.all(20), children: const [
    Center(child: CircleAvatar(radius: 42, backgroundColor: Color(0xFFEAF1FA), child: Icon(Icons.person, size: 50, color: Color(0xFF123B69)))),
    SizedBox(height: 14), Center(child: Text('Rishva', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
    SizedBox(height: 24),
    _ProfileRow(label: 'Register Number', value: 'Your Register Number'),
    _ProfileRow(label: 'Phone Number', value: 'Your Phone Number'),
    _ProfileRow(label: 'Email ID', value: 'Your Email ID'),
    _ProfileRow(label: 'Student Category', value: 'Selected during registration'),
    _ProfileRow(label: 'Hostel / Room', value: 'Not added yet'),
  ]);
}

class _ProfileRow extends StatelessWidget {
  final String label, value;
  const _ProfileRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(title: Text(label, style: const TextStyle(fontSize: 12, color: Colors.blueGrey)), subtitle: Text(value, style: const TextStyle(fontWeight: FontWeight.w700))));
}

class MonthlyMenuPage extends StatelessWidget {
  const MonthlyMenuPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: AppData.instance,
    builder: (_, __) => Scaffold(appBar: AppBar(title: const Text('Monthly Menu')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: AppData.instance.menus.length, itemBuilder: (_, i) {
      final m = AppData.instance.menus[i];
      return Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFEAF1FA), child: Icon(Icons.restaurant_menu_outlined, color: Color(0xFF123B69))), title: Text(m.date, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('Snack: ${m.snack}\nEgg: ${m.egg}'), isThreeLine: true));
    })),
  );
}

class _SummaryItem extends StatelessWidget {
  final IconData icon; final String title; final String value;
  const _SummaryItem({required this.icon, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)), child: Row(children: [Icon(icon, color: Colors.white, size: 25), const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 3), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))]))]));
}


class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});
  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final user = TextEditingController();
  final pass = TextEditingController();
  bool hide = true;

  @override
  void dispose() { user.dispose(); pass.dispose(); super.dispose(); }

  void login() {
    if (user.text.trim().isEmpty || pass.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter Admin ID and Password')),
      );
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboardPage()));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFFF7F9FC),
    appBar: AppBar(title: const Text('Admin / Warden Login')),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const SizedBox(height: 24),
        const CircleAvatar(radius: 42, backgroundColor: Color(0xFFEAF1FA), child: Icon(Icons.admin_panel_settings, size: 48, color: Color(0xFF123B69))),
        const SizedBox(height: 18),
        const Text('Admin Panel', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: Color(0xFF123B69))),
        const SizedBox(height: 6),
        const Text('Manage students, menus and tokens', style: TextStyle(color: Colors.blueGrey)),
        const SizedBox(height: 30),
        TextField(controller: user, decoration: _adminField('Admin ID', Icons.person_outline)),
        const SizedBox(height: 14),
        TextField(controller: pass, obscureText: hide, decoration: _adminField('Password', Icons.lock_outline).copyWith(suffixIcon: IconButton(onPressed: () => setState(() => hide = !hide), icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined)))),
        const SizedBox(height: 22),
        SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: login, style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF123B69), foregroundColor: Colors.white), child: const Text('Login to Admin Panel', style: TextStyle(fontWeight: FontWeight.w800)))),
      ]),
    ),
  );

  InputDecoration _adminField(String hint, IconData icon) => InputDecoration(
    hintText: hint, prefixIcon: Icon(icon, color: Colors.blueGrey), filled: true, fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFDCE3EB))),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFDCE3EB))),
  );
}

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: AppData.instance,
    builder: (_, __) {
      final snacks = AppData.instance.tokens.where((t) => t.type == 'Snack').length;
      final eggs = AppData.instance.tokens.where((t) => t.type == 'Egg').length;
      return Scaffold(
        backgroundColor: const Color(0xFFF7F9FC),
        appBar: AppBar(title: const Text('Admin Dashboard'), actions: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.logout_outlined))]),
        body: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF123B69), borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Good Morning, Warden 👋', style: TextStyle(color: Colors.white70)), SizedBox(height: 6), Text('Hostel Token Admin', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Live app data', style: TextStyle(color: Colors.white70))])),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: _AdminStat(title: 'Students', value: '${AppData.instance.students.length}', icon: Icons.groups_outlined)), const SizedBox(width: 10), Expanded(child: _AdminStat(title: 'Snack Today', value: '$snacks', icon: Icons.cookie_outlined))]),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: _AdminStat(title: 'Egg Today', value: '$eggs', icon: Icons.egg_outlined)), const SizedBox(width: 10), Expanded(child: _AdminStat(title: 'Menu Days', value: '${AppData.instance.menus.length}', icon: Icons.calendar_month_outlined))]),
          const SizedBox(height: 24),
          const Text('Management', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF123B69))), const SizedBox(height: 10),
          _AdminAction(icon: Icons.calendar_month_outlined, title: 'Menu Management', subtitle: 'Add daily snack & egg menu', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminMenuPage()))),
          _AdminAction(icon: Icons.confirmation_number_outlined, title: 'Token Management', subtitle: 'View generated tokens', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminTokenPage()))),
          _AdminAction(icon: Icons.groups_outlined, title: 'Student Management', subtitle: 'View student categories and details', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminStudentsPage()))),
        ])),
      );
    },
  );
}

class _AdminStat extends StatelessWidget {
  final String title, value; final IconData icon;
  const _AdminStat({required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE1E7EE))), child: Row(children: [Icon(icon, color: const Color(0xFF123B69)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 12, color: Colors.blueGrey)), const SizedBox(height: 3), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF123B69)))]))]));
}

class _AdminAction extends StatelessWidget {
  final IconData icon; final String title, subtitle; final VoidCallback onTap;
  const _AdminAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(onTap: onTap, leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FA), child: Icon(icon, color: const Color(0xFF123B69))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right)));
}

class AdminMenuPage extends StatelessWidget {
  const AdminMenuPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: AppData.instance,
    builder: (_, __) => Scaffold(appBar: AppBar(title: const Text('Menu Management')), floatingActionButton: FloatingActionButton.extended(onPressed: () => _menuDialog(context), icon: const Icon(Icons.add), label: const Text('Add Menu')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: AppData.instance.menus.length, itemBuilder: (_, i) { final m=AppData.instance.menus[i]; return _MenuAdminTile(date:m.date, snack:m.snack, egg:m.egg); })),
  );

  static void _menuDialog(BuildContext context) {
    final date=TextEditingController(); final snack=TextEditingController(); final egg=TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Add Menu'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: date, decoration: const InputDecoration(labelText:'Date')), TextField(controller: snack, decoration: const InputDecoration(labelText:'Snack')), TextField(controller: egg, decoration: const InputDecoration(labelText:'Egg Type'))]), actions: [TextButton(onPressed:()=>Navigator.pop(context), child:const Text('Cancel')), ElevatedButton(onPressed:(){ if(date.text.trim().isEmpty||snack.text.trim().isEmpty||egg.text.trim().isEmpty)return; AppData.instance.addMenu(MenuDay(date:date.text.trim(), snack:snack.text.trim(), egg:egg.text.trim())); Navigator.pop(context);}, child:const Text('Save'))]));
  }
}

class _MenuAdminTile extends StatelessWidget {
  final String date, snack, egg;
  const _MenuAdminTile({required this.date, required this.snack, required this.egg});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FA), child: Text(date.split(' ').first)), title: Text(date, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('Snack: $snack\nEgg: $egg'), isThreeLine: true, trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.edit_outlined))));
}

class AdminTokenPage extends StatelessWidget {
  const AdminTokenPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: AppData.instance, builder: (_, __) => Scaffold(appBar: AppBar(title: const Text('Token Management')), body: AppData.instance.tokens.isEmpty ? const Center(child: Text('No tokens generated yet')) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: AppData.instance.tokens.length, itemBuilder: (_,i){ final t=AppData.instance.tokens[i]; return _AdminTokenTile(name:'Current Student', reg:'REG001', type:'${t.type} Token', qty:'${t.quantity}', status:t.status); })));
}

class _AdminTokenTile extends StatelessWidget {
  final String name, reg, type, qty, status;
  const _AdminTokenTile({required this.name, required this.reg, required this.type, required this.qty, required this.status});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FA), child: Icon(type.startsWith('Egg') ? Icons.egg_outlined : Icons.cookie_outlined, color: const Color(0xFF123B69))), title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('$reg • $type • Qty $qty'), trailing: Text(status, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w700))));
}

class AdminStudentsPage extends StatelessWidget {
  const AdminStudentsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Student Management')), body: ListView(padding: const EdgeInsets.all(16), children: const [
    _StudentAdminTile(name: 'Student 001', reg: 'REG001', category: 'Management Quota'),
    _StudentAdminTile(name: 'Student 002', reg: 'REG002', category: 'Government – General Rank'),
    _StudentAdminTile(name: 'Student 003', reg: 'REG003', category: 'Government – 7.5% Category'),
  ]));
}

class _StudentAdminTile extends StatelessWidget {
  final String name, reg, category;
  const _StudentAdminTile({required this.name, required this.reg, required this.category});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFEAF1FA), child: Icon(Icons.person_outline, color: Color(0xFF123B69))), title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('$reg\n$category'), isThreeLine: true));
}
