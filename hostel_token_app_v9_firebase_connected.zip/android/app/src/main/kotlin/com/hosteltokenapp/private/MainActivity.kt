package com.hosteltokenapp.private

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
